#!/bin/sh
set -e
CONSUL_ADDR="${CONSUL_HTTP_ADDR:-consul:8500}"
TPL="${HAPROXY_TPL:-/tpl/haproxy.cfg.tpl}"
CFG="${HAPROXY_CFG:-/tmp/haproxy.cfg}"
WAIT_MAX="${HAPROXY_WAIT_FOR_SERVICES:-45}"

# Ждём появления хотя бы одного инстанса service1-jetty в Consul (или таймаут)
echo "Waiting for service1-jetty in Consul (max ${WAIT_MAX}s)..."
i=0
while [ "$i" -lt "$WAIT_MAX" ]; do
  if consul-template -consul-addr="${CONSUL_ADDR}" -once \
    -template="${TPL}:${CFG}:true" 2>/dev/null && ! grep -q "server placeholder" "${CFG}"; then
    echo "Found service1-jetty instances."
    break
  fi
  i=$((i + 3))
  sleep 3
done
# Если так и не появились — рендерим с placeholder, потом watcher подхватит
if grep -q "server placeholder" "${CFG}" 2>/dev/null; then
  consul-template -consul-addr="${CONSUL_ADDR}" -once -template="${TPL}:${CFG}:true"
  echo "No instances yet; will reload when they register."
fi

haproxy -f "${CFG}" -p /var/run/haproxy.pid &

exec consul-template -consul-addr="${CONSUL_ADDR}" \
  -template="${TPL}:${CFG}:sh /tmp/reload_lf.sh"
